import logging

import port.api.d3i_props as d3i_props
import port.api.props as props
from port.api.commands import (
    CommandSystemDonate,
    CommandSystemExit,
    CommandSystemLog,
    CommandUIRender,
)
from port.helpers import uploads

_logger = logging.getLogger(__name__)


def render_page(
    header_text: props.Translatable,
    body: (
        props.PropsUIPromptRadioInput
        | props.PropsUIPromptConsentForm
        | d3i_props.PropsUIPromptConsentFormViz
        | props.PropsUIPromptFileInput
        | d3i_props.PropsUIPromptFileInputMultiple
        | d3i_props.PropsUIPromptQuestionnaire
        | props.PropsUIPromptConfirm
    ),
) -> CommandUIRender:
    """
    Renders the UI components for a donation page.

    This function assembles various UI components including a header, body, and footer
    to create a complete donation page. It uses the provided header text and body content
    to customize the page.

    Args:
        header_text (props.Translatable): The text to be displayed in the header.
            This should be a translatable object to support multiple languages.
        body (
            props.PropsUIPromptRadioInput |
            props.PropsUIPromptConsentForm |
            props.PropsUIPromptFileInput |
            props.PropsUIPromptConfirm |
        ): The main content of the page. It must be compatible with `props.PropsUIPageDonation`.

    Returns:
        CommandUIRender: A render command object containing the fully assembled page. Must be yielded.
    """
    header = props.PropsUIHeader(header_text)
    page = props.PropsUIPageDataSubmission("does not matter", header, body)
    return CommandUIRender(page)


def get_validation_hint(platform_name: str) -> props.Translations | None:
    if platform_name in {"YouTube", "Instagram", "Facebook", "TikTok"}:
        return {
            "en": "In particular, make sure that the file format is set to 'json'",
            "nl": "Check in het bijzonder dat het bestandsformaat 'json' is gekozen",
            "es": "En particular, asegúrese de que el formato del archivo esté establecido en 'json'",
            "lt": "Visų pirma, įsitikinkite, kad failo formatas nustatytas į 'json'",
            "ro": "În special, asigurați-vă că formatul fișierului este setat la 'json'",
        }


def generate_retry_prompt(platform_name: str) -> props.PropsUIPromptConfirm:
    """
    Generate a bilingual retry prompt for file processing errors.

    Returns a PropsUIPromptConfirm with "Try again" (ok → PayloadTrue) and
    "Continue" (cancel → PayloadFalse) buttons. Using standard feldspar
    PropsUIPromptConfirm instead of d3i PropsUIPromptRetry which only
    renders a single button. See data-collector/AD0002 for the broader
    decision on custom vs standard prompt components.

    Args:
        platform_name: The name of the platform whose file could not be processed.
    """

    text: props.Translations = {
        "en": (
            f"Unfortunately, we cannot process your {platform_name} file. Try again to select a different file. "
            f"If you selected the right file, something probably went wrong in requesting it from {platform_name}. "
            "Please download the file again, and pay careful attention to the download instructions."
        ),
        "nl": (
            f"Helaas, kunnen we uw {platform_name} bestand niet verwerken. Probeer opnieuw als u een ander bestand wilt kiezen. "
            f"Als u wel het goede bestand heeft gekozen, is er waarschijnlijk iets misgegaan bij het opvragen van het bestand bij {platform_name}. "
            "Vraag a.u.b. het bestand opnieuw op, en lees daarbij zorgvuldig de downloadinstructies."
        ),
        "es": (
            f"Lamentablemente, no podemos procesar su archivo de {platform_name}. Intente de nuevo para seleccionar un archivo diferente. "
            f"Si seleccionó el archivo correcto, probablemente algo salió mal al solicitarlo a {platform_name}. "
            "Por favor, descargue el archivo nuevamente y preste mucha atención a las instrucciones de descarga."
        ),
        "lt": (
            f"Deja, negalime apdoroti jūsų {platform_name} failo. Bandykite dar kartą, kad pasirinktumėte kitą failą. "
            f"Jei pasirinkote tinkamą failą, greičiausiai kažkas nutiko negerai jį užsakant iš {platform_name}. "
            "Prašome dar kartą atsisiųsti failą ir atidžiai laikytis atsisiuntimo instrukcijų."
        ),
        "ro": (
            f"Din păcate, nu putem procesa fișierul dvs. {platform_name}. Încercați din nou pentru a selecta un alt fișier. "
            f"Dacă ați selectat fișierul corect, probabil că ceva nu a mers bine la solicitarea acestuia de la {platform_name}. "
            "Vă rugăm să descărcați fișierul din nou și să acordați atenție instrucțiunilor de descărcare."
        ),
    }
    hint = get_validation_hint(platform_name)
    if hint:
        for lang, msg in text.items():
            text[lang] = f"{msg} {hint.get(lang)}"

    ok = props.Translatable(
        {
            "en": "Try again",
            "nl": "Probeer opnieuw",
            "es": "Intentar de nuevo",
            "lt": "Bandyti dar kartą",
            "ro": "Încercați din nou",
        }
    )
    cancel = props.Translatable({"en": "Continue", "nl": "Doorgaan", "es": "Continuar", "lt": "Tęsti", "ro": "Continuați"})
    return props.PropsUIPromptConfirm(props.Translatable(text), ok, cancel)


def generate_file_prompt(
    extensions: str, multiple: bool = False
) -> props.PropsUIPromptFileInput | d3i_props.PropsUIPromptFileInputMultiple:
    """
    Generates a file input prompt for selecting file(s) for a platform.
    This function creates a bilingual (English and Dutch) file input prompt
    that instructs the user to select file(s) they've received from a platform
    and stored on their device.

    The prompt that is returned by this function needs to be rendered using: yield result = render_page(...)
    result.value should then contain the file handle(s).
    In case multiple is true, a list with file handles is returned.

    Args:
        extensions (str): A collection of allowed MIME types.
            For example: "application/zip, text/plain, application/json"
        multiple (bool, optional): Whether to allow multiple file selection.
            Defaults to False.

    Returns:
        props.PropsUIPromptFileInput | d3i_props.PropsUIPromptFileInputMultiple:
            A file input prompt object containing the description text and
            allowed file extensions. If multiple=True, returns a
            PropsUIPromptFileInputMultiple object for selecting multiple files.
    """
    description = props.Translatable(
        {
            "en": "Please follow the download instructions and choose the file that you stored on your device.",
            "nl": "Volg de download instructies en kies het bestand dat u opgeslagen heeft op uw apparaat.",
            "es": "Por favor, siga las instrucciones de descarga y elija el archivo que guardó en su dispositivo.",
            "lt": "Vykdykite atsisiuntimo instrukcijas ir pasirinkite failą, kurį išsaugojote savo įrenginyje",
            "ro": "Vă rugăm să urmați instrucțiunile de descărcare și să alegeți fișierul pe care l-ați salvat pe dispozitivul dvs.",
        }
    )
    if multiple:
        return d3i_props.PropsUIPromptFileInputMultiple(description, extensions)

    return props.PropsUIPromptFileInput(description, extensions)


def generate_review_data_prompt(
    description: props.Translatable, table_list: list[d3i_props.PropsUIPromptConsentFormTableViz]
) -> d3i_props.PropsUIPromptConsentFormViz:
    """
    Generates a data review form with a list of tables and a description, including default donate question and button.
    The participant can review these tables before they will be send to the researcher. If the participant consents to sharing the data
    the data will be stored at the configured storage location.

    Args:
        table_list (list[props.PropsUIPromptConsentFormTableViz]): A list of consent form tables to be included in the prompt.
        description (props.Translatable): A translatable description text for the consent prompt.

    Returns:
        props.PropsUIPromptConsentForm: A structured consent form object containing the provided table list, description,
        and default values for donate question and button.
    """
    donate_question = props.Translatable(
        {
            "en": "Do you want to share this data for research?",
            "nl": "Wilt u deze gegevens delen voor onderzoek?",
            "es": "¿Desea compartir estos datos para investigación?",
            "lt": "Ar norite pasidalinti šiais duomenimis tyrimų tikslais?",
            "ro": "Doriți să împărtășiți aceste date pentru cercetare?",
        }
    )

    donate_button = props.Translatable(
        {
            "en": "Yes, share for research",
            "nl": "Ja, deel voor onderzoek",
            "es": "Sí, compartir para investigación",
            "lt": "Taip, dalintis tyrimų tikslais",
            "ro": "Da, împărtășiți pentru cercetare",
        }
    )

    return d3i_props.PropsUIPromptConsentFormViz(
        tables=table_list, description=description, donate_question=donate_question, donate_button=donate_button
    )


def donate(key: str, json_string: str) -> CommandSystemDonate:
    """
    Initiates a donation process using the provided key and data.

    This function triggers the donation process by passing a key and a JSON-formatted string
    that contains donation information.

    Args:
        key (str): The key associated with the donation process. The key will be used in the file name.
        json_string (str): A JSON-formatted string containing the donated data.

    Returns:
        CommandSystemDonate: A system command that initiates the donation process. Must be yielded.
    """
    return CommandSystemDonate(key, json_string)


def exit(code: int, info: str) -> CommandSystemExit:
    """
    Exits Next with the provided exit code and additional information.
    This if the code reaches this function, it will return to the task list in Next.

    Args:
        code (int): The exit code representing the type or status of the exit.
        info (str): A string containing additional information about the exit.

    Returns:
        CommandSystemExit: A system command that initiates the exit process in Next.

    Examples::

        yield exit(0, "Success")
    """
    return CommandSystemExit(code, info)


def emit_log(level: str, message: str):
    """Yield a CommandSystemLog to the host via the command protocol.

    Use via `yield from emit_log(...)` in generators (FlowBuilder, script.py).
    The host receives the log immediately; the PayloadVoid response is discarded.

    Messages sent through this function reach mono's /api/feldspar/log.
    They MUST be PII-free — no file paths, exception text, or participant data.

    Examples::

        yield from emit_log("info", "[LinkedIn] Consent: accepted")
        yield from emit_log("info", "Starting platform: Facebook")
    """
    _ = yield CommandSystemLog(level=level, message=message)


def generate_radio_prompt(
    title: props.Translatable, description: props.Translatable, items: list[str]
) -> props.PropsUIPromptRadioInput:
    """
    General purpose prompt selection menu
    """
    radio_items: list[props.RadioItem] = [{"id": i, "value": item} for i, item in enumerate(items)]
    return props.PropsUIPromptRadioInput(title, description, radio_items)


def generate_questionnaire() -> d3i_props.PropsUIPromptQuestionnaire:
    """
    Administer a basic questionnaire in Port.

    This function generates a prompt which can be rendered with render_page().
    The questionnaire demonstrates all currently implemented question types.
    In the current implementation, all questions are optional.

    You can build in logic by:
    - Chaining questionnaires together
    - Using extracted data in your questionnaires

    Usage:
        prompt = generate_questionnaire()
        results = yield render_page(header_text, prompt)

    The results.value contains a JSON string with question answers that
    can then be donated with donate().
    """

    questionnaire_description = props.Translatable(
        translations={
            "en": "Customer Satisfaction Survey for our Online Store",
            "nl": "Klanttevredenheidsonderzoek voor onze Online Winkel",
        }
    )

    open_question = props.Translatable(
        translations={"en": "How can we improve our services?", "nl": "Hoe kunnen we onze diensten verbeteren?"}
    )

    mc_question = props.Translatable(
        translations={"en": "How would you rate your overall experience?", "nl": "Hoe zou u uw algemene ervaring beoordelen?"}
    )

    mc_choices = [
        props.Translatable(translations={"en": "Excellent", "nl": "Uitstekend"}),
        props.Translatable(translations={"en": "Good", "nl": "Goed"}),
        props.Translatable(translations={"en": "Average", "nl": "Gemiddeld"}),
        props.Translatable(translations={"en": "Poor", "nl": "Slecht"}),
        props.Translatable(translations={"en": "Very Poor", "nl": "Zeer slecht"}),
    ]

    checkbox_question = props.Translatable(
        translations={
            "en": "Which of our products have you purchased? (Select all that apply)",
            "nl": "Welke van onze producten heeft u gekocht? (Selecteer alle toepasselijke)",
        }
    )

    checkbox_choices = [
        props.Translatable(translations={"en": "Electronics", "nl": "Elektronica"}),
        props.Translatable(translations={"en": "Clothing", "nl": "Kleding"}),
        props.Translatable(translations={"en": "Home Goods", "nl": "Huishoudelijke artikelen"}),
        props.Translatable(translations={"en": "Books", "nl": "Boeken"}),
        props.Translatable(translations={"en": "Food Items", "nl": "Voedingsproducten"}),
    ]

    open_ended_question = d3i_props.PropsUIQuestionOpen(id=1, question=open_question)

    multiple_choice_question = d3i_props.PropsUIQuestionMultipleChoice(id=2, question=mc_question, choices=mc_choices)

    checkbox_question_obj = d3i_props.PropsUIQuestionMultipleChoiceCheckbox(
        id=3, question=checkbox_question, choices=checkbox_choices
    )

    return d3i_props.PropsUIPromptQuestionnaire(
        description=questionnaire_description, questions=[multiple_choice_question, checkbox_question_obj, open_ended_question]
    )


def render_no_data_page(platform_name: str) -> CommandUIRender:
    """Render 'no relevant data found' with acknowledge button.

    Caller should yield and await response before returning.
    """
    header = props.PropsUIHeader(
        props.Translatable(
            {
                "en": f"No data found",
                "nl": f"Geen gegevens gevonden",
                "es": "No se encontraron datos",
                "lt": "Duomenų nerasta",
                "ro": "Nu s-au găsit date",
            }
        )
    )
    body = props.PropsUIPromptConfirm(
        text=props.Translatable(
            {
                "en": f"Unfortunately, no relevant data was found in your {platform_name} file.",
                "nl": f"Helaas zijn er geen relevante gegevens gevonden in uw {platform_name} bestand.",
                "es": f"Desafortunadamente, no se encontraron datos relevantes en su archivo de {platform_name}.",
                "lt": f"Deja, jūsų {platform_name} faile nerasta jokių aktualių duomenų.",
                "ro": f"Din păcate, nu s-au găsit date relevante în fișierul dvs. {platform_name}.",
            }
        ),
        ok=props.Translatable({"en": "Continue", "nl": "Doorgaan", "es": "Continuar", "lt": "Tęsti", "ro": "Continuați"}),
        cancel=props.Translatable({"en": "Continue", "nl": "Doorgaan", "es": "Continuar", "lt": "Tęsti", "ro": "Continuați"}),
    )
    page = props.PropsUIPageDataSubmission(platform_name, header, body)
    return CommandUIRender(page)


def render_safety_error_page(platform_name: str, error: Exception) -> CommandUIRender:
    """Render file safety error page.

    Caller should yield and await response before returning.
    """
    header = props.PropsUIHeader(
        props.Translatable(
            {
                "en": "File cannot be processed",
                "nl": "Bestand kan niet worden verwerkt",
                "es": "El archivo no se puede procesar",
                "lt": "Failo apdoroti nepavyksta",
                "ro": "Fișierul nu poate fi procesat",
            }
        )
    )

    if isinstance(error, uploads.TranslatableException):
        text = error.get_translatable(platform_name)
    else:
        text = props.Translatable(
            {
                "en": f"Your {platform_name} file could not be processed: {error}",
                "nl": f"Uw {platform_name} bestand kon niet worden verwerkt: {error}",
                "es": f"Su archivo de {platform_name} no se pudo procesar: {error}",
                "lt": f"Jūsų {platform_name} failo apdoroti nepavyko: {error}",
                "ro": f"Fișierul dvs. {platform_name} nu a putut fi procesat: {error}",
            }
        )

    body = props.PropsUIPromptConfirm(
        text=text,
        ok=props.Translatable({"en": "Continue", "nl": "Doorgaan", "es": "Continuar", "lt": "Tęsti", "ro": "Continuați"}),
        cancel=props.Translatable({"en": "Continue", "nl": "Doorgaan", "es": "Continuar", "lt": "Tęsti", "ro": "Continuați"}),
    )
    page = props.PropsUIPageDataSubmission(platform_name, header, body)
    return CommandUIRender(page)


def render_donate_failure_page(platform_name: str) -> CommandUIRender:
    """Render donation failure page.

    Caller should yield and await response before returning.
    """
    header = props.PropsUIHeader(
        props.Translatable(
            {
                "en": "Data submission failed",
                "nl": "Gegevensinzending mislukt",
                "es": "Error al enviar los datos",
                "lt": "Nepavyko pateikti duomenų",
                "ro": "Trimiterea datelor a eșuat",
            }
        )
    )
    body = props.PropsUIPromptConfirm(
        text=props.Translatable(
            {
                "en": f"Unfortunately, your {platform_name} data could not be submitted. Please try again later.",
                "nl": f"Helaas konden uw {platform_name} gegevens niet worden ingediend. Probeer het later opnieuw.",
                "es": f"Desafortunadamente, sus datos de {platform_name} no pudieron ser enviados. Por favor, inténtelo de nuevo más tarde.",
                "lt": f"Deja, jūsų {platform_name} duomenų nepavyko pateikti. Bandykite dar kartą vėliau.",
                "ro": f"Din păcate, datele dvs. {platform_name} nu au putut fi trimise. Vă rugăm să încercați din nou mai târziu.",
            }
        ),
        ok=props.Translatable({"en": "Continue", "nl": "Doorgaan", "es": "Continuar", "lt": "Tęsti", "ro": "Continuați"}),
        cancel=props.Translatable({"en": "Continue", "nl": "Doorgaan", "es": "Continuar", "lt": "Tęsti", "ro": "Continuați"}),
    )
    page = props.PropsUIPageDataSubmission(platform_name, header, body)
    return CommandUIRender(page)


def handle_donate_result(result) -> bool:
    """Inspect donate result. Returns True on success, False on failure.

    eyra/feldspar develop (Feb 2026+) returns PayloadResponse for
    CommandSystemDonate with value.success indicating outcome. Older
    feldspar and FakeBridge (dev mode) return PayloadVoid (fire-and-forget).

    PayloadResponse → check value.success (production path, checked first)
    PayloadVoid / None → True (dev mode / backward-compat)
    Anything else → log warning, return False
    """
    if result is None:
        return True

    result_type = getattr(result, "__type__", None)

    if result_type == "PayloadResponse":
        # value is { success: bool, key: str, status: int, error?: str }
        return bool(result.value.success)

    if result_type == "PayloadVoid":
        return True

    _logger.warning("Unexpected donate result type: %s", result_type)
    return False
